package etf.ri.rma.newsfeedapp.screen

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import etf.ri.rma.newsfeedapp.data.network.ImagaDAO
import etf.ri.rma.newsfeedapp.data.network.NewsDAO
import etf.ri.rma.newsfeedapp.data.NewsData
import etf.ri.rma.newsfeedapp.model.NewsItem
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException

@RequiresApi(Build.VERSION_CODES.O)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewsDetailsScreen(
    newsId: String,
    onNavigateBack: () -> Unit,
    onNavigateToDetails: (String) -> Unit
) {
    val newsDao = NewsDAO()
    val imagaDao = ImagaDAO()
    var newsItem by remember { mutableStateOf<NewsItem>(NewsItem()) }
    val scrollState = rememberScrollState()
    var similarStories by remember { mutableStateOf<List<NewsItem>>(emptyList()) }
    var tags by remember { mutableStateOf<List<String>>(emptyList()) }

    LaunchedEffect(newsId) {
        newsItem = newsDao.getNewsByUUID(newsId)
        val imageUrl = newsItem.imageUrl?.toString() ?: ""
        similarStories = newsDao.getSimilarStories(newsId)

        if(newsItem.imageTags.isEmpty()) {
            tags = imagaDao.getTags(imageUrl)
            NewsDAO.cachedNews.find { it.uuid == newsId }?.let { cachedItem ->
                cachedItem.imageTags = tags as ArrayList<String>
            }
        } else tags = newsItem.imageTags
    }

    val relatedNews = remember(newsItem) {
        NewsData.getAllNews()
            .filter { it.category == newsItem.category && it.uuid != newsItem.uuid }
            .sortedWith(compareBy(
                { item ->
                    try {
                        val formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy")
                        val currentDate = LocalDate.parse(newsItem.publishedDate, formatter)
                        val itemDate = LocalDate.parse(item.publishedDate, formatter)
                        kotlin.math.abs(itemDate.toEpochDay() - currentDate.toEpochDay())
                    } catch (e: DateTimeParseException) {
                        Long.MAX_VALUE
                    }
                },
                { it.title }
            ))
            .take(2)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Detalji vijesti") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Nazad")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = newsItem.title,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.testTag("details_title")
            )
            
            Text(
                text = newsItem.snippet,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.testTag("details_snippet")
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Kategorija: ${newsItem.category}",
                    modifier = Modifier.testTag("details_category")
                )
                Text(
                    text = "Izvor: ${newsItem.source}",
                    modifier = Modifier.testTag("details_source")
                )
            }
            
            Text(
                text = "Datum objave: ${newsItem.publishedDate}",
                modifier = Modifier.testTag("details_date")
            )

            Column {
                tags.forEach { tag ->
                    Text(text = tag)
                }
            }
            
            if (similarStories.isNotEmpty()) {
                Text(
                    text = "Povezane vijesti iz iste kategorije",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                
                similarStories.forEachIndexed { index, relatedItem ->
                    TextButton(
                        onClick = { onNavigateToDetails(relatedItem.uuid) },
                        modifier = Modifier.testTag("related_news_title_${index + 1}")
                    ) {
                        Text(relatedItem.title)
                    }
                }
            }
            
            Button(
                onClick = onNavigateBack,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("details_close_button")
            ) {
                Text("Zatvori detalje")
            }
        }
    }
} 