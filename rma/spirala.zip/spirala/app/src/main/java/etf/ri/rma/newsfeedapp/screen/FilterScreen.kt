package etf.ri.rma.newsfeedapp.screen

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Done
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.navigation.NavController
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun FilterScreen(
    onApplyFilters: (String, String?, List<String>) -> Unit,
    navController: NavController?,
    initialCategory: String = "Sve",
    initialDateRange: String? = null,
    initialUnwantedWords: List<String> = emptyList()
) {
    var selectedCategory by remember { mutableStateOf(initialCategory) }
    var dateRange by remember { mutableStateOf(initialDateRange) }
    var unwantedWords by remember { mutableStateOf(initialUnwantedWords) }

    var showDatePicker by remember { mutableStateOf(false) }
    var newUnwantedWord by remember { mutableStateOf("") }
    val datePickerState = rememberDateRangePickerState()
    val formatter = remember { SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Filtriraj po kategoriji",
                style = MaterialTheme.typography.titleMedium
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChipComponent(
                    assignedCategory = "politics",
                    selectedCategory = selectedCategory,
                    onClick = { selectedCategory = it },
                    tag = "filter_chip_pol"
                )
                FilterChipComponent(
                    assignedCategory = "sports",
                    selectedCategory = selectedCategory,
                    onClick = { selectedCategory = it },
                    tag = "filter_chip_spo"
                )
                FilterChipComponent(
                    assignedCategory = "science",
                    selectedCategory = selectedCategory,
                    onClick = { selectedCategory = it },
                    tag = "filter_chip_sci"
                )
                FilterChipComponent(
                    assignedCategory = "tech",
                    selectedCategory = selectedCategory,
                    onClick = { selectedCategory = it },
                    tag = "filter_chip_tech"
                )
                FilterChipComponent(
                    assignedCategory = "Sve",
                    selectedCategory = selectedCategory,
                    onClick = { selectedCategory = it },
                    tag = "filter_chip_all"
                )
            }
        }

        item {
            Text(
                text = "Filtriraj po datumu",
                style = MaterialTheme.typography.titleMedium
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = dateRange ?: "Odaberi opseg datuma",
                    modifier = Modifier.testTag("filter_daterange_display")
                )
                Button(
                    onClick = { showDatePicker = true },
                    modifier = Modifier.testTag("filter_daterange_button")
                ) {
                    Text("Odaberi")
                }
            }
        }

        item {
            Text(
                text = "Filtriraj po nepoželjnim riječima",
                style = MaterialTheme.typography.titleMedium
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = newUnwantedWord,
                    onValueChange = { newUnwantedWord = it },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("filter_unwanted_input"),
                    label = { Text("Dodaj riječ") }
                )
                IconButton(
                    onClick = {
                        if (newUnwantedWord.isNotBlank() && 
                            !unwantedWords.any { it.equals(newUnwantedWord, ignoreCase = true) }) {
                            unwantedWords = unwantedWords + newUnwantedWord
                            newUnwantedWord = ""
                        }
                    },
                    modifier = Modifier.testTag("filter_unwanted_add_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Dodaj riječ")
                }
            }
            Column(
                modifier = Modifier.testTag("filter_unwanted_list")
            ) {
                unwantedWords.forEach { word ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(word)
                        IconButton(onClick = {
                            unwantedWords = unwantedWords - word
                        }) {
                            Icon(Icons.Default.Done, contentDescription = "Ukloni riječ")
                        }
                    }
                }
            }
        }
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Button(
                    onClick = {
                        onApplyFilters(selectedCategory, dateRange, unwantedWords)
                        navController?.navigate("home")
                    },
                    modifier = Modifier.testTag("filter_apply_button")
                ) {
                    Text("Primijeni filtere")
                }
            }
        }
    }

    if (showDatePicker) {
        Dialog(onDismissRequest = { showDatePicker = false }) {
            Column(
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(8.dp)
            ) {
                DateRangePicker(
                    state = datePickerState,
                    modifier = Modifier
                        .padding(4.dp)
                        .heightIn(max = 500.dp),
                    title = {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp, vertical = 16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Odaberite vremenski period",
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                    },
                    headline = {
                        val startDate = datePickerState.selectedStartDateMillis?.let { millis ->
                            formatter.format(Date(millis))
                        } ?: "Početni datum"

                        val endDate = datePickerState.selectedEndDateMillis?.let { millis ->
                            formatter.format(Date(millis))
                        } ?: "Krajnji datum"

                        Box(
                            modifier = Modifier
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$startDate - $endDate",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                )

                Spacer(Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = { showDatePicker = false }) {
                        Text("Otkaži")
                    }
                    Spacer(Modifier.width(8.dp))
                    TextButton(onClick = {
                        val start = datePickerState.selectedStartDateMillis
                        val end = datePickerState.selectedEndDateMillis

                        if (start != null && end != null) {
                            dateRange = "${formatter.format(Date(start))};${formatter.format(Date(end))}"
                        }
                        showDatePicker = false
                    }) {
                        Text("OK")
                    }
                }
            }
        }
    }
}