package etf.ri.rma.newsfeedapp.data.network.exception

import java.io.IOException

class InvalidUUIDException : IOException {

    /**
     * Constructs a new [InvalidImageURLException] with the specified detail message.
     *
     * @param message The detail message (which is saved for later retrieval by the [Throwable.message] method).
     */
    constructor(message: String) : super(message)

    /**
     * Constructs a new [InvalidImageURLException] with the specified detail message and cause.
     *
     * @param message The detail message (which is saved for later retrieval by the [Throwable.message] method).
     * @param cause The cause (which is saved for later retrieval by the [Throwable.cause] method).
     * (A null value is permitted, and indicates that the cause is nonexistent or unknown.)
     */
    constructor(message: String, cause: Throwable?) : super(message, cause)

    /**
     * Constructs a new [InvalidImageURLException] with the specified cause and a detail message of
     * `(cause == null ? null : cause.toString())` (which typically contains the class and detail message of `cause`).
     * This constructor is useful for exceptions that are little more than wrappers for other throwables.
     *
     * @param cause The cause (which is saved for later retrieval by the [Throwable.cause] method).
     * (A null value is permitted, and indicates that the cause is nonexistent or unknown.)
     */
    constructor(cause: Throwable?) : super(cause)

    // You can add more constructors if needed, for example, one with a message, cause,
    // enableSuppression, and writableStackTrace, though less common for simple custom exceptions.
    // constructor(message: String?, cause: Throwable?, enableSuppression: Boolean, writableStackTrace: Boolean) :
    //     super(message, cause, enableSuppression, writableStackTrace)
}