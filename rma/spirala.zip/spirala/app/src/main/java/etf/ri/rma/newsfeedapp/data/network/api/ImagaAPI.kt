package etf.ri.rma.newsfeedapp.data.network.api

import etf.ri.rma.newsfeedapp.data.ImaggaResponse
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Query

interface ImagaApiService {
    @GET("v2/tags")
    @Headers("Authorization: Basic YWNjXzZlYTFjNzk1NmM2NDk4MjpjODRmY2Y3NjI3NGJkM2IyNjVhZjZkNjBmODAyN2Q2Nw==")
    suspend fun getTags(
        @Query("image_url") imageUrl: String,
    ): ImaggaResponse
}