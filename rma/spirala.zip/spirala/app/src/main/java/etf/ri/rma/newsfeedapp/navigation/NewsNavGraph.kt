package etf.ri.rma.newsfeedapp.navigation

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import etf.ri.rma.newsfeedapp.data.network.NewsDAO
import etf.ri.rma.newsfeedapp.data.network.NewsDAO.Companion.cachedNews
import etf.ri.rma.newsfeedapp.model.NewsItem
import etf.ri.rma.newsfeedapp.screen.FilterScreen
import etf.ri.rma.newsfeedapp.screen.NewsDetailsScreen
import etf.ri.rma.newsfeedapp.screen.NewsFeedScreen
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun NewsNavGraph() {
    val navController = rememberNavController()
    val newsDao = NewsDAO()

    var newsItems by remember { mutableStateOf<List<NewsItem>>(newsDao.getAllStories()) }
    var filteredNews by remember { mutableStateOf(newsItems) }

    var selectedCategory by remember { mutableStateOf("Sve") }
    var dateRange by remember { mutableStateOf<String?>(null) }
    var unwantedWords by remember { mutableStateOf<List<String>>(emptyList()) }

    val coroutineScope = rememberCoroutineScope()

    fun filterNews(): List<NewsItem> {
        return newsItems.filter { item ->
            val dateMatch = if (dateRange != null) {
                try {
                    val (startDateStr, endDateStr) = dateRange!!.split(";")
                    val formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy")
                    val itemDate = LocalDate.parse(item.publishedDate, formatter)
                    val startDate = LocalDate.parse(startDateStr, formatter)
                    val endDate = LocalDate.parse(endDateStr, formatter)
                    !itemDate.isBefore(startDate) && !itemDate.isAfter(endDate)
                } catch (e: Exception) {
                    true
                }
            } else true

            val wordMatch = unwantedWords.none { word ->
                item.title.contains(word, ignoreCase = true) ||
                        item.snippet.contains(word, ignoreCase = true)
            }

            dateMatch && wordMatch
        }
    }

    fun getTopStoriesByCategory(category: String) {
        coroutineScope.launch {
            val newNews = newsDao.getTopStoriesByCategory(category)
            val additionalNews = cachedNews
                .filter { it.category == category && newNews.none { new -> new.uuid == it.uuid } }

            newsItems = newNews + additionalNews
            filteredNews = filterNews()
        }
    }

    fun onChangeCategory(newCategory: String) {
        selectedCategory = newCategory
        if(newCategory == "Sve") {
            newsItems = newsDao.getAllStories()
            filteredNews = filterNews()
            return
        }
        getTopStoriesByCategory(newCategory)
    }

    fun applyFilters(newCategory: String, newDateRange: String?, newUnwantedWords: List<String>) {
        onChangeCategory(newCategory)
        dateRange = newDateRange
        unwantedWords = newUnwantedWords
        filteredNews = filterNews()
    }

    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            NewsFeedScreen(news = filteredNews,
                currentCategory = selectedCategory,
                changeCategory = { newCategory -> onChangeCategory(newCategory) },
                navController = navController)
        }
        composable(
            "details/{id}",
            arguments = listOf(navArgument("id") { type = NavType.StringType })
        ) { backStackEntry ->
            val id = backStackEntry.arguments?.getString("id") ?: ""

            NewsDetailsScreen(
                newsId = id,
                onNavigateBack = { navController.navigate("home") },
                onNavigateToDetails = { newId ->
                    navController.navigate("details/${newId}") {
                        popUpTo("details/$newId") { inclusive = true }
                        launchSingleTop = true
                    }
                }
            )
        }
        composable("filters") {
            FilterScreen(
                onApplyFilters = { category, dateRange, unwantedWords -> applyFilters(category, dateRange, unwantedWords) },
                navController = navController,
                initialCategory = selectedCategory,
                initialDateRange = dateRange,
                initialUnwantedWords = unwantedWords
            )
        }
    }
}
