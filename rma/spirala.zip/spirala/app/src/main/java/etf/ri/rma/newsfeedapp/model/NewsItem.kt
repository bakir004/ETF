package etf.ri.rma.newsfeedapp.model

data class NewsItem(
    val uuid: String = "", // koristite kao key za lazylistu i neka bude jedinstveno za svaku vijest
    val title: String = "",
    val snippet: String = "",
    val imageUrl: String? = "", // URL slike - ne koristi se sada
    var category: String = "", // primjer "Politika", "Sport"
    var isFeatured: Boolean = false, // Tip novosti “Featured” ili “Non featured”
    val source: String = "",
    val publishedDate: String = "",
    var imageTags: ArrayList<String> = ArrayList<String>()
)
