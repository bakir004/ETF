package etf.ri.rma.newsfeedapp.screen

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Done
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import etf.ri.rma.newsfeedapp.model.NewsItem

@Composable
fun FilterChipComponent(
    selectedCategory: String,
    onClick: (String) -> Unit,
    assignedCategory: String,
    tag: String,
) {
    FilterChip(
        onClick = {
            onClick(assignedCategory)
        },
        label = {
            Text(assignedCategory)
        },
        modifier = Modifier.testTag(tag),
        selected = selectedCategory == assignedCategory,
        leadingIcon = if (selectedCategory == assignedCategory) {
            {
                Icon(
                    imageVector = Icons.Filled.Done,
                    contentDescription = "Done icon",
                    modifier = Modifier.size(FilterChipDefaults.IconSize)
                )
            }
        } else {
            null
        },
    )
}

@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun NewsFeedScreen(
    news: List<NewsItem> = emptyList(),
    currentCategory: String = "Sve",
    changeCategory: (String) -> Unit,
    navController: NavController?
) {
    Column(
        modifier = Modifier.padding(top = 40.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChipComponent(
                assignedCategory = "politics",
                selectedCategory = currentCategory,
                onClick = { category -> changeCategory(category) },
                tag = "filter_chip_pol",
            )
            FilterChipComponent(
                assignedCategory = "sports",
                selectedCategory = currentCategory,
                onClick = { category -> changeCategory(category) },
                tag = "filter_chip_spo",
            )
            FilterChipComponent(
                assignedCategory = "science", // Changed to "Nauka" to match potential single category or adjust as needed
                selectedCategory = currentCategory,
                onClick = { category -> changeCategory(category) },
                tag = "filter_chip_sci",
            )
            FilterChipComponent(
                assignedCategory = "tech", // Changed to "Nauka" to match potential single category or adjust as needed
                selectedCategory = currentCategory,
                onClick = { category -> changeCategory(category) },
                tag = "filter_chip_tech",
            )
            FilterChipComponent(
                assignedCategory = "Sve", // Changed to "All" to match currentCategory default
                selectedCategory = currentCategory,
                onClick = { category -> changeCategory(category) },
                tag = "filter_chip_sve",
            )
        }
        Row (
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                onClick = { navController?.navigate("filters") },
                label = { Text("Više filtera ...") }, // "More filters ..."
                modifier = Modifier.testTag("filter_chip_more"),
                selected = false
            )
        }
        if(news.isNotEmpty()) {
            NewsList( // Assuming NewsList is another composable you have
                newsItems = news,
                navController = navController
            )
        } else {
            MessageCard(currentCategory) // Assuming MessageCard is another composable
        }
    }
}