package etf.ri.rma.newsfeedapp.data

import etf.ri.rma.newsfeedapp.model.NewsItem

object NewsData {
    private val newsItems = listOf(
        NewsItem(
            uuid = "2c7e1c56-97b5-4e04-8cd1-8a2c0dd661a8",
            title = "Свыше 14 ГБ/с: KIOXIA показала SSD Exceria Pro G2 формата M.2",
            snippet = "На текущий момент Exceria Plus G4 остается самым быстрым потребительским NVMe SSD от KIOXIA. Оснащён?...",
            imageUrl = "https://www.hardwareluxx.de/images/cdn02/uploads/2025/May/amazed_fan_5p/kioxia_exceria_pro_g2_1_300px.jpeg",
            category = "tech",
            isFeatured = false,
            source = "hardwareluxx.ru",
            publishedDate = "2025-05-23T13:20:33.000000Z",
            imageTags = arrayListOf()
        ),
        NewsItem(
            uuid = "88443576-1954-4cda-932c-5dd3d1511e2f",
            title = "OpenAI and SoftBank to Build AI Data Center in UAE",
            snippet = "TOKYO, May 23 (News On Japan) - OpenAI, the developer behind the conversational AI ChatGPT, announced on May 22nd plans to build a large-scale AI data center in...",
            imageUrl = "https://i2.ytimg.com/vi/EwA52HmN8mQ/mqdefault.jpg",
            category = "general",
            isFeatured = false,
            source = "newsonjapan.com",
            publishedDate = "2025-05-23T13:20:28.000000Z",
            imageTags = arrayListOf()
        ),
        NewsItem(
            uuid = "14ad5cad-6d97-4038-a68a-28e66bb853e1",
            title = "美 배터리 보조금 유지에 K-배터리 ‘한숨 돌려’…中 견제 효과도",
            snippet = "미국 하원이 22일(현지시간) 트럼프 전 대통령의 감세 공약을 반영한 세제 개편안을 통과시킨 가운데, 국내 배터리 업계?...",
            imageUrl = "https://cdn.fins.co.kr/news/thumbnail/202505/104405_21790_200_v150.jpg",
            category = "general",
            isFeatured = false,
            source = "fins.co.kr",
            publishedDate = "2025-05-23T13:20:18.000000Z",
            imageTags = arrayListOf()
        ),
        NewsItem(
            uuid = "f7af8ff8-ca05-4e59-a199-97a16b6d189f",
            title = "首次合成金属性碘烯单层—论文—科学网",
            snippet = "",
            imageUrl = "https://news.sciencenet.cn/myeditor/net/upload/image/20250523/6388360301132679053019691.png",
            category = "science", // Picking the first category if multiple are present
            isFeatured = false,
            source = "paper.sciencenet.cn",
            publishedDate = "2025-05-23T13:20:00.000000Z",
            imageTags = arrayListOf("亚稳态", "二维材料", "石墨烯")
        ),
        NewsItem(
            uuid = "723e306b-62bd-4468-a03f-81c4321fed0b",
            title = "雷军对标Model Y！老外拆解小米YU7背后：引领中国20万级SUV市场",
            snippet = "雷军对标Model Y！老外拆解小米YU7背后：引领中国20万级SUV市场\n\n快科技5月23日消息，小米YU7发布了，不少国外媒体也是密?...",
            imageUrl = "https://img1.mydrivers.com/img/20250523/42d107796ae14a45abdef853057f9d3f.png",
            category = "tech",
            isFeatured = false,
            source = "news.mydrivers.com",
            publishedDate = "2025-05-23T13:19:45.000000Z",
            imageTags = arrayListOf("雷军对标Model Y！老外拆解小米YU7背后：引领中国20万级SUV市场", "快科技")
        ),
        NewsItem(
            uuid = "b518a28e-969f-4793-94fa-6bb1d86b41a0",
            title = "Senior Chinese, U.S. diplomats hold phone call",
            snippet = "Chinese Vice Foreign Minister Ma Zhaoxu held a phone conversation on Thursday, with U.S. Deputy Secretary of State Christopher Landau, during which they exchang...",
            imageUrl = "http://image.cns.com.cn/ecns_editor/transform/20250522/x04s-hersmuc8113668.jpg",
            category = "politics",
            isFeatured = false,
            source = "ecns.cn",
            publishedDate = "2025-05-23T13:19:44.000000Z",
            imageTags = arrayListOf()
        ),
        NewsItem(
            uuid = "9563c36c-b5d5-4c0c-82d7-30ed99bea5d5",
            title = "Castellammare - Osservatorio criminalità, la città un Laboratorio di Trasformazioni Politiche e Sociali",
            snippet = "Presentato oggi alla stampa un importante studio del professor Bracaccio Luciano dell'Università Federico II di Napoli, che analizza la complessità sociale e ...",
            imageUrl = "https://www.stabiachannel.it/public/News/Immagini/OsservatorioCamorra230525.jpg",
            category = "sports",
            isFeatured = false,
            source = "StabiaChannel.it",
            publishedDate = "2025-05-23T13:19:33.000000Z",
            imageTags = arrayListOf("stabia", "castellammare", "juve", "video", "web", "news", "notizie", "stabiese", "channel", "gragnano", "lettere", "casola", "pimonte", "pompei", "sorrento", "vico equense", "massa lubrense", "meta di sorrento", "piano di sorrento", "sant'agnello", "torre annunziata", "torre del greco", "juvestabia", "castellammare di stabia", "player", "stabiesi")
        ),
        NewsItem(
            uuid = "7c3f0c73-2a27-4446-b6b4-88e56bcdcf8e",
            title = "Gaming Factory: sprzedaż JDM zgodna z założeniami",
            snippet = "O ponad 20 proc. w ciągu ostatnich trzech dni spadł kurs Gaming Factory. To pokłosie premiery gry „JDM: Japanese Drift Master”, która odbyła się w śr...",
            imageUrl = "https://images.pb.pl/filtered/5d86a472-08c1-4861-b419-f15a8a6795f4/1dbe69d8-84c9-4961-b34d-47345d45ce81_og_1200_630.jpg",
            category = "politics",
            isFeatured = false,
            source = "pb.pl",
            publishedDate = "2025-05-23T13:19:09.000000Z",
            imageTags = arrayListOf()
        ),
        NewsItem(
            uuid = "946da171-28a5-4693-a1f2-86a335a116e7",
            title = "ニール・ヤング＆クロム・ハーツ 初スタジオアルバム『Talkin To The Trees』からタイトル曲公開",
            snippet = "",
            imageUrl = "https://amassing2.sakura.ne.jp/image/jacket/300/2025/138269.jpg",
            category = "sports",
            isFeatured = false,
            source = "amass.jp",
            publishedDate = "2025-05-23T13:19:00.000000Z",
            imageTags = arrayListOf("音楽", "洋楽", "邦楽", "music", "アニメ", "映画", "特撮", "cd", "dvd", "Blu-ray")
        ),
        NewsItem(
            uuid = "22ea2fbe-625c-4057-bc29-1ad2c219c706",
            title = "Chinese scientists discover rare millisecond pulsar with eclipsing companion using FAST telescope",
            snippet = "A research team led by Han Jinlin from the National Astronomical Observatories of the Chinese Academy of Sciences has discovered a rare millisecond pulsar using...",
            imageUrl = "http://image.cns.com.cn/ecns_editor/transform/20250522/x04s-hersmuc8113668.jpg",
            category = "science",
            isFeatured = false,
            source = "ecns.cn",
            publishedDate = "2025-05-23T13:18:35.000000Z",
            imageTags = arrayListOf()
        )
    )

    fun getAllNews(): List<NewsItem> {
        return newsItems
    }
}