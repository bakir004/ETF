package etf.ri.rma.newsfeedapp.data

import com.google.gson.annotations.SerializedName
import etf.ri.rma.newsfeedapp.model.NewsItem

data class NewsResponse(
    @SerializedName("data") val data: List<NewsFromApi>
)

data class NewsFromApi(
    @SerializedName("uuid") val uuid: String,
    @SerializedName("title") val title: String,
    @SerializedName("description") val description: String?, // Nullable as it can be null or absent
    @SerializedName("keywords") val keywords: String?,    // Nullable
    @SerializedName("snippet") val snippet: String,
    @SerializedName("url") val url: String,
    @SerializedName("image_url") val imageUrl: String?,    // Nullable
    @SerializedName("language") val language: String,
    @SerializedName("published_at") val publishedAt: String,
    @SerializedName("source") val source: String,
    @SerializedName("categories") val categories: List<String>,
    @SerializedName("relevance_score") val relevanceScore: Double?, // Nullable, and `Double` for numerical scores
    @SerializedName("locale") val locale: String?       // Nullable
)

data class ImaggaResponse(
    @SerializedName("result") val result: ResultObject,
    @SerializedName("status") val status: StatusObject
)

data class StatusObject(
    @SerializedName("type") val type: String,
    @SerializedName("text") val text: String
)

data class ResultObject(
    @SerializedName("tags") val tags: List<TagObject>
)

data class TagObject(
    @SerializedName("confidence") val confidence: Float,
    @SerializedName("tag") val tag: TagName
)

data class TagName(
    @SerializedName("en") val en: String
)

//data class SingleBookResponse(
//    @SerializedName("item") val item: BookItem
//)
//
//data class BookItem(
//    @SerializedName("id") val id: String,
//    @SerializedName("volumeInfo") val volumeInfo: VolumeInfo
//)
//
//data class VolumeInfo(
//    @SerializedName("title") val title: String?,
//    @SerializedName("authors") val authors: List<String>?,
//    @SerializedName("publisher") val publisher: String?,
//    @SerializedName("categories") val categories: List<String>?,
//    @SerializedName("infoLink") val infoLink: String?,
//    @SerializedName("description") val description: String?,
//    @SerializedName("imageLinks") val imageLinks: ImageLinks?
//)
//
//data class ImageLinks(
//    @SerializedName("thumbnail") val thumbnail: String?
//)

fun NewsFromApi.toNews(): NewsItem {
    return NewsItem(
        uuid = this.uuid,
        title = this.title, // 'title' from API is non-nullable String
        snippet = this.snippet, // 'snippet' from API is non-nullable String
        imageUrl = this.imageUrl, // 'imageUrl' from API is nullable String?
        category = this.categories[0],
        isFeatured = false, // Defaulting to false, adjust logic as needed
        source = this.source, // 'source' from API is non-nullable String
        publishedDate = this.publishedAt, // 'publishedAt' from API is non-nullable String
        imageTags = ArrayList<String>()
    )
}